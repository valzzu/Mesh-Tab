## Getting Started

firstly head over to [jlcpcb](https://jlcpcb.com) and hit order now.

then either chooce the non panelized or the panelized version of the gerber file depending on ur needs.
when u know whitch one u need drag it or click add gerber file.
if u chose the panelized version, click panel by customer and set it to 2x1

![starting1](/Images/Guide_images/starting1.png)

![starting2](/Images/Guide_images/starting2.png)

if 'Single piece, pls help me repeat the data' is not highlighted select that, files only have data for one pcb. Only relevant if u chose panelized version
![starting3](/Images/Guide_images/starting3.png)

![starting4](/Images/Guide_images/starting4.png)

if u want to jlc to assemble the esp32 then do not untick the checkbox but do note it will cost more.

![starting5](/Images/Guide_images/starting5.png)

![starting6](/Images/Guide_images/starting6.png)

after selecting description hit add to cart

![starting7](/Images/Guide_images/starting7.png)

For shipping select 'Global Standard Direct Line' for shipping 

# Additional hardware

[Ra-01sh](https://vi.aliexpress.com/item/1005002561194884.html) - select the version with the ipex connector

[esp32 s3 wroom 1 N16R2](https://vi.aliexpress.com/item/1005005230800143.html) - select S3-WROOM-1-N16R2

[LEDs](https://vi.aliexpress.com/item/1005006205983912.html) - select red and green, both have 100 leds. or if u don't want 100 each choose the 5 colors x20 led kit

[3.2 inch display](https://vi.aliexpress.com/item/1005006258575617.html) - chooce the version with touch screen

[buzzer](https://vi.aliexpress.com/item/1005006260328559.html)

battery:

[5000mAh](https://vi.aliexpress.com/item/1005005216499731.html)

[8000mAh](https://vi.aliexpress.com/item/1005004423785699.html)

[connector for battery](https://vi.aliexpress.com/item/1005006623049916.html)

[ipex to sma](https://vi.aliexpress.com/item/4000848776660.html) - select IPEX to SMA-K and 5cm for length

antenna:

[868Mhz](https://vi.aliexpress.com/item/32972870968.html) - DO NOT SELECT RP-SMA

[868Mhz and 915Mhz](https://vi.aliexpress.com/item/1005004607615001.html) - DO NOT SELECT RP-SMA
